import { createFileRoute } from "@tanstack/react-router";
import { useState, createContext, useContext, useEffect, useMemo } from "react";
import { Briefcase, FileText, Calendar, Save, Loader2, Search, Sparkles, MapPin, Building2, Upload, CheckCircle2, XCircle, Target, Rocket, ArrowRight, Eye, ExternalLink, Copy, Lightbulb, Wand2, ListChecks, Tags, LayoutList, ClipboardCopy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

const WEBHOOK_URL = "https://cold-king-627d.srikrishnacharansai.workers.dev/webhook";

const INDIA_CITIES = [
  "Remote", "Bengaluru", "Mumbai", "Delhi", "Hyderabad", "Chennai", "Pune", "Kolkata",
  "Ahmedabad", "Gurgaon", "Noida", "Jaipur", "Chandigarh", "Kochi", "Thiruvananthapuram",
  "Indore", "Bhubaneswar", "Coimbatore", "Visakhapatnam", "Lucknow", "Nagpur", "Mysuru",
  "Surat", "Vadodara", "Mangaluru", "Bhopal", "Patna", "Guwahati",
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "JobPilot AI — Your AI Job Application Assistant" },
      { name: "description", content: "Search jobs, tailor resumes, and prep for interviews with AI." },
    ],
  }),
  component: App,
});

type TabId = "search" | "resume" | "prep" | "schedule";

const TABS: { id: TabId; label: string; icon: typeof Briefcase }[] = [
  { id: "search", label: "Job Search", icon: Search },
  { id: "resume", label: "Resume Coach", icon: FileText },
  { id: "prep", label: "Interview Prep", icon: Sparkles },
  { id: "schedule", label: "Save & Schedule", icon: Calendar },
];

/* ----------------- Global App State ----------------- */
type SelectedJob = {
  title: string;
  company: string;
  location?: string;
  description: string;
  applyLink?: string;
};

type CoachOutput = {
  matchScore: number | null;
  matchSummary: string;
  skillsToAdd: { skill: string; context: string }[];
  bulletsToImprove: { original: string; suggested: string }[];
  keywordsToInject: { keyword: string; sentence: string }[];
  sectionRecommendations: string[];
  snippets: string[];
} | null;

type AppState = {
  selectedJob: SelectedJob | null;
  setSelectedJob: (j: SelectedJob | null) => void;
  coach: CoachOutput;
  setCoach: (c: CoachOutput) => void;
  prep: {
    interviewDate: string; startDate: string; hoursPerDay: string;
    focusAreas: string[]; prepPlan: string;
  };
  setPrep: (p: AppState["prep"]) => void;
  goTo: (t: TabId) => void;
};

const AppCtx = createContext<AppState | null>(null);
const useApp = () => {
  const c = useContext(AppCtx);
  if (!c) throw new Error("AppCtx missing");
  return c;
};

async function postJSON(path: string, body: unknown) {
  const targetUrl = WEBHOOK_URL + path;
  let res: Response;
  try {
    res = await fetch(targetUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new Error("Connection failed. Please try again.");
  }
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) throw new Error(typeof data === "string" && data ? data : data?.message || "Connection failed. Please try again.");
  return data;
}

function copyText(s: string) {
  if (!s) return;
  navigator.clipboard.writeText(s).then(
    () => toast.success("Copied"),
    () => toast.error("Copy failed"),
  );
}

function Spinner({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-12">
      <Loader2 className="h-10 w-10 animate-spin text-primary" />
      <p className="text-sm text-muted-foreground">{message}</p>
    </div>
  );
}

function App() {
  const [tab, setTab] = useState<TabId>("search");
  const [selectedJob, setSelectedJob] = useState<SelectedJob | null>(null);
  const [coach, setCoach] = useState<CoachOutput>(null);
  const [prep, setPrep] = useState<AppState["prep"]>({
    interviewDate: "", startDate: "", hoursPerDay: "2", focusAreas: [], prepPlan: "",
  });

  const ctx = useMemo<AppState>(() => ({
    selectedJob, setSelectedJob,
    coach, setCoach,
    prep, setPrep,
    goTo: setTab,
  }), [selectedJob, coach, prep]);

  return (
    <AppCtx.Provider value={ctx}>
      <div className="relative min-h-screen text-foreground overflow-x-hidden">
        <Toaster theme="dark" position="top-right" />

        <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute top-[-10%] left-[-5%] h-[480px] w-[480px] rounded-full bg-indigo-500/25 blur-3xl animate-blob" />
          <div className="absolute top-[20%] right-[-10%] h-[520px] w-[520px] rounded-full bg-violet-500/20 blur-3xl animate-blob" style={{ animationDelay: "-6s" }} />
          <div className="absolute bottom-[-10%] left-[30%] h-[420px] w-[420px] rounded-full bg-sky-500/15 blur-3xl animate-blob" style={{ animationDelay: "-12s" }} />
        </div>

        <header className="glass-strong sticky top-0 z-20 border-b border-white/5">
          <div className="mx-auto max-w-6xl px-4 py-4 flex items-center gap-3">
            <div className="relative h-10 w-10 rounded-xl btn-gradient flex items-center justify-center shadow-lg">
              <Rocket className="h-5 w-5 -rotate-45" />
              <span aria-hidden className="absolute inset-0 rounded-xl animate-ping bg-primary/40 opacity-50" style={{ animationDuration: "2.5s" }} />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight tracking-tight">JobPilot <span className="text-gradient">AI</span></h1>
              <p className="text-xs text-muted-foreground">Your AI job application assistant</p>
            </div>
          </div>
          <nav className="mx-auto max-w-6xl px-2 pb-1 flex gap-1 overflow-x-auto">
            {TABS.map(({ id, label, icon: Icon }) => {
              const active = tab === id;
              return (
                <button
                  key={id}
                  onClick={() => setTab(id)}
                  className={`relative flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                    active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {label}
                  {active && (
                    <span className="absolute left-3 right-3 -bottom-1 h-0.5 rounded-full" style={{ backgroundImage: "linear-gradient(90deg,#6366f1,#8b5cf6)" }} />
                  )}
                </button>
              );
            })}
          </nav>
        </header>

        <main className="mx-auto max-w-6xl px-4 py-8 md:py-12">
          <div key={tab} className="animate-fade-in-up">
            {tab === "search" && <JobSearch />}
            {tab === "resume" && <ResumeTailor />}
            {tab === "prep" && <PrepPlan />}
            {tab === "schedule" && <SaveSchedule />}
          </div>
        </main>
      </div>
    </AppCtx.Provider>
  );
}

/* -------- helpers for job parsing -------- */
function jobApplyLink(j: any): string {
  const raw = j?.applyLink || j?.applyUrl || j?.apply_link || j?.url || j?.link || j?.jobUrl || "";
  if (!raw || raw === "#") return "";
  return raw;
}
function jobDescription(j: any): string {
  return j?.description || j?.jobDescription || j?.jd || j?.fullDescription || j?.summary || "";
}
function googleSearchFallback(title: string, company: string): string {
  return `https://www.google.com/search?q=${encodeURIComponent(`${title} ${company} job apply`)}`;
}
function openApply(job: { title?: string; company?: string; applyLink?: string }) {
  const link = job.applyLink && job.applyLink !== "#"
    ? job.applyLink
    : googleSearchFallback(job.title || "", job.company || "");
  window.open(link, "_blank", "noopener,noreferrer");
}

/* -------- SCREEN 1: Job Search -------- */
function JobSearch() {
  const { setSelectedJob, goTo } = useApp();
  const [form, setForm] = useState({ jobTitle: "", skills: "", location: "", salaryRange: "", excludeKeywords: "" });
  const [loading, setLoading] = useState(false);
  const [jobs, setJobs] = useState<any[] | null>(null);
  const [viewJob, setViewJob] = useState<any | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setJobs(null);
    try {
      const { jobTitle, skills, location, salaryRange, excludeKeywords } = form;
      const locations = location
        .split(",")
        .map(s => s.trim())
        .filter(Boolean);
      const queries = locations.length > 0 ? locations : [""];

      const results = await Promise.allSettled(
        queries.map(loc =>
          fetch("https://cold-king-627d.srikrishnacharansai.workers.dev/webhook/search-jobs", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Accept": "application/json" },
            body: JSON.stringify({ jobTitle, skills, location: loc, salaryRange, excludeKeywords }),
          }).then(r => r.json())
        )
      );

      const combined: any[] = [];
      const seen = new Set<string>();
      for (const r of results) {
        if (r.status !== "fulfilled") continue;
        const data = r.value;
        const list = Array.isArray(data) ? data : data?.jobs || data?.results || [];
        for (const j of list) {
          const key = `${(j.title || j.jobTitle || "").toLowerCase()}|${(j.company || j.companyName || "").toLowerCase()}|${jobApplyLink(j)}`;
          if (seen.has(key)) continue;
          seen.add(key);
          combined.push(j);
        }
      }
      setJobs(combined);
      if (combined.length === 0) toast.info("No jobs found.");
    } catch (err: any) {
      toast.error(err.message || "Connection failed. Please try again.");
    } finally { setLoading(false); }
  };

  const applyWithAI = (job: any) => {
    console.log("[JobPilot] Selected job (full object):", job);
    console.log("[JobPilot] applyLink resolved:", jobApplyLink(job));
    setSelectedJob({
      title: job.title || job.jobTitle || "Untitled role",
      company: job.company || job.companyName || "Unknown",
      location: job.location || "",
      description: jobDescription(job),
      applyLink: jobApplyLink(job),
    });
    toast.success("Job selected — opening Resume Coach");
    goTo("resume");
  };

  return (
    <div className="grid gap-6 md:grid-cols-[400px_1fr]">
      <Card className="p-6">
        <h2 className="text-xl font-bold mb-1 tracking-tight">Find your next role</h2>
        <p className="text-sm text-muted-foreground mb-5">Search across the internet with AI</p>
        <form onSubmit={submit} className="space-y-4">
          <Field label="Job Title"><Input required value={form.jobTitle} onChange={e => setForm({ ...form, jobTitle: e.target.value })} placeholder="Senior ML Engineer" /></Field>
          <Field label="Skills (comma separated)"><Input value={form.skills} onChange={e => setForm({ ...form, skills: e.target.value })} placeholder="Python, PyTorch, SQL" /></Field>
          <Field label="Locations (comma separated)">
            <Input
              value={form.location}
              onChange={e => setForm({ ...form, location: e.target.value })}
              placeholder="Bengaluru, Mumbai, Remote"
              list="india-cities"
            />
            <datalist id="india-cities">
              {INDIA_CITIES.map(c => <option key={c} value={c} />)}
            </datalist>
            <p className="text-[11px] text-muted-foreground mt-1">Each location is searched separately, results are merged.</p>
          </Field>
          <Field label="Salary Range"><Input value={form.salaryRange} onChange={e => setForm({ ...form, salaryRange: e.target.value })} placeholder="₹20 - 40 LPA" /></Field>
          <Field label="Exclude Keywords"><Input value={form.excludeKeywords} onChange={e => setForm({ ...form, excludeKeywords: e.target.value })} placeholder="contract, junior" /></Field>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Search className="h-4 w-4 mr-2" /> Find Jobs</>}
          </Button>
        </form>
      </Card>

      <div>
        {loading && <Card className="p-6"><Spinner message="Searching jobs across the internet..." /></Card>}
        {!loading && jobs && jobs.length === 0 && <Card className="p-10 text-center text-muted-foreground">No jobs found. Try different criteria.</Card>}
        {!loading && jobs && jobs.length > 0 && (
          <div className="space-y-4">
            {jobs.map((j, i) => <JobCard key={i} job={j} onView={() => setViewJob(j)} onApply={() => applyWithAI(j)} />)}
          </div>
        )}
        {!loading && !jobs && (
          <Card className="p-10 text-center text-muted-foreground border-dashed">
            <Search className="h-10 w-10 mx-auto mb-3 opacity-50" />
            Results will appear here
          </Card>
        )}
      </div>

      <Dialog open={!!viewJob} onOpenChange={(o) => !o && setViewJob(null)}>
        <DialogContent className="glass-strong border-white/10 max-w-3xl max-h-[85vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-xl pr-8">
              {viewJob?.title || viewJob?.jobTitle || "Job Description"}
            </DialogTitle>
            <p className="text-sm text-muted-foreground">
              {viewJob?.company || viewJob?.companyName} {viewJob?.location ? `· ${viewJob.location}` : ""}
            </p>
          </DialogHeader>
          <div className="text-sm whitespace-pre-wrap text-foreground/90 leading-relaxed">
            {jobDescription(viewJob) || "No description provided."}
          </div>
          <div className="flex flex-wrap gap-2 pt-2">
            <Button onClick={() => { if (viewJob) { applyWithAI(viewJob); setViewJob(null); } }} className="flex-1 min-w-[160px]">
              <Sparkles className="h-4 w-4 mr-2" /> Apply with AI
            </Button>
            {viewJob && (
              <Button variant="outline" onClick={() => openApply({
                title: viewJob.title || viewJob.jobTitle,
                company: viewJob.company || viewJob.companyName,
                applyLink: jobApplyLink(viewJob),
              })}>
                <ExternalLink className="h-4 w-4 mr-2" />
                {jobApplyLink(viewJob) ? "Apply Direct" : "Search on Google"}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function MatchRing({ value }: { value: number }) {
  const pct = Math.max(0, Math.min(100, value));
  const r = 26;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  const color = pct >= 75 ? "#22c55e" : pct >= 50 ? "#f59e0b" : "#ef4444";
  return (
    <div className="relative h-16 w-16 shrink-0">
      <svg className="h-16 w-16 -rotate-90" viewBox="0 0 64 64">
        <circle cx="32" cy="32" r={r} stroke="rgba(255,255,255,0.08)" strokeWidth="5" fill="none" />
        <circle cx="32" cy="32" r={r} stroke={color} strokeWidth="5" fill="none"
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.8s ease" }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-sm font-bold" style={{ color }}>{Math.round(pct)}</span>
        <span className="text-[9px] uppercase tracking-wider text-muted-foreground -mt-0.5">Match</span>
      </div>
    </div>
  );
}

function JobCard({ job, onView, onApply }: { job: any; onView: () => void; onApply: () => void }) {
  const title = job.title || job.jobTitle || "Untitled role";
  const company = job.company || job.companyName || "Unknown";
  const location = job.location || "—";
  const link = jobApplyLink(job);
  const rawScore = job.matchScore ?? job.score ?? job.match;
  const score = typeof rawScore === "number" ? rawScore : typeof rawScore === "string" ? parseFloat(rawScore) : null;
  const matched: string[] = job.matchedSkills || job.matched_skills || job.skills || [];
  return (
    <Card className="p-5 transition-all hover:border-white/15 hover:-translate-y-0.5">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0 flex-1">
          <h3 className="font-semibold text-base truncate">{title}</h3>
          <div className="flex flex-wrap items-center gap-3 mt-1.5 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><Building2 className="h-3.5 w-3.5" />{company}</span>
            <span className="inline-flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" />{location}</span>
          </div>
        </div>
        {score != null && !isNaN(score) && <MatchRing value={score} />}
      </div>
      {matched.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-4">
          {matched.slice(0, 8).map((s, i) => (
            <span key={i} className="text-xs px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-foreground/90">{s}</span>
          ))}
        </div>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        <Button size="sm" variant="outline" onClick={onView}><Eye className="h-4 w-4 mr-1.5" /> View JD</Button>
        <Button size="sm" onClick={onApply}><Sparkles className="h-4 w-4 mr-1.5" /> Apply with AI</Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            console.log("[JobPilot] Apply clicked — job object:", job);
            openApply({ title, company, applyLink: link });
          }}
          title={link || "No direct link — will search Google"}
        >
          <ExternalLink className="h-4 w-4 mr-1.5" />
          {link ? "Apply" : "Search on Google"}
        </Button>
      </div>
    </Card>
  );
}

/* -------- Coach response parser -------- */
function parseCoach(data: any): CoachOutput {
  if (!data) return null;
  const d = typeof data === "string" ? safeJSON(data) : data;
  const root = d?.coach || d?.resumeCoach || d;

  const toArr = (v: any): any[] => Array.isArray(v) ? v : v ? [v] : [];

  const skillsRaw = toArr(root?.skillsToAdd || root?.skills_to_add || root?.missingSkills);
  const skillsToAdd = skillsRaw.map((x: any) =>
    typeof x === "string"
      ? { skill: x, context: "" }
      : { skill: x.skill || x.name || "", context: x.context || x.how || x.suggestion || "" }
  ).filter(x => x.skill);

  const bulletsRaw = toArr(root?.bulletsToImprove || root?.bullets_to_improve || root?.bulletRewrites);
  const bulletsToImprove = bulletsRaw.map((x: any) =>
    typeof x === "string"
      ? { original: "", suggested: x }
      : { original: x.original || x.before || x.from || "", suggested: x.suggested || x.rewrite || x.after || x.to || "" }
  ).filter(x => x.suggested);

  const kwRaw = toArr(root?.keywordsToInject || root?.keywords_to_inject || root?.keywords);
  const keywordsToInject = kwRaw.map((x: any) =>
    typeof x === "string"
      ? { keyword: x, sentence: "" }
      : { keyword: x.keyword || x.term || "", sentence: x.sentence || x.suggestion || x.usage || "" }
  ).filter(x => x.keyword);

  const secRaw = toArr(root?.sectionRecommendations || root?.section_recommendations || root?.sections);
  const sectionRecommendations = secRaw.map((x: any) =>
    typeof x === "string" ? x : x.recommendation || x.text || JSON.stringify(x)
  ).filter(Boolean);

  const snipRaw = toArr(root?.snippets || root?.readySnippets || root?.copySnippets);
  const snippets = snipRaw.map((x: any) =>
    typeof x === "string" ? x : x.text || x.snippet || x.content || ""
  ).filter(Boolean);

  const scoreRaw = root?.matchScore ?? root?.match_score ?? root?.score ?? root?.atsScore;
  const matchScore = typeof scoreRaw === "number" ? scoreRaw : typeof scoreRaw === "string" ? parseFloat(scoreRaw) || null : null;
  const matchSummary = root?.matchAnalysis || root?.match_analysis || root?.summary || root?.analysis || "";

  return {
    matchScore,
    matchSummary: typeof matchSummary === "string" ? matchSummary : JSON.stringify(matchSummary),
    skillsToAdd,
    bulletsToImprove,
    keywordsToInject,
    sectionRecommendations,
    snippets,
  };
}
function safeJSON(s: string): any { try { return JSON.parse(s); } catch { return { summary: s }; } }

/* -------- SCREEN 2: Resume Coach -------- */
function ResumeTailor() {
  const { selectedJob, coach, setCoach, goTo } = useApp();
  const [companyName, setCompanyName] = useState(selectedJob?.company || "");
  const [targetRole, setTargetRole] = useState(selectedJob?.title || "");
  const [jobDescription, setJobDescription] = useState(selectedJob?.description || "");
  const [resumeText, setResumeText] = useState("");
  const [fileName, setFileName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedJob) {
      setCompanyName(selectedJob.company);
      setTargetRole(selectedJob.title);
      setJobDescription(selectedJob.description);
    }
  }, [selectedJob]);

  const handleFile = (file: File) => {
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => setResumeText(String(reader.result || ""));
    reader.readAsText(file);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resumeText) { toast.error("Please upload a resume PDF"); return; }
    setLoading(true); setCoach(null);
    try {
      const data = await postJSON("/tailor-resume", {
        resumeText, jobDescription, targetRole, companyName,
        mode: "coach",
      });
      const parsed = parseCoach(data);
      setCoach(parsed);
      toast.success("AI Resume Coach ready");
    } catch (err: any) {
      toast.error(err.message || "Coach failed");
    } finally { setLoading(false); }
  };

  const applyLink = selectedJob?.applyLink || "";

  return (
    <div className="grid gap-6 md:grid-cols-[400px_1fr]">
      <Card className="p-6">
        <h2 className="text-xl font-bold mb-1 tracking-tight">AI Resume Coach</h2>
        <p className="text-sm text-muted-foreground mb-5">Targeted edits to beat the ATS</p>
        {selectedJob && (
          <div className="mb-4 px-3 py-2 rounded-lg bg-primary/10 border border-primary/20 text-xs text-foreground/90">
            Pre-filled from <strong>{selectedJob.title}</strong> @ {selectedJob.company}
          </div>
        )}
        {selectedJob && (
          applyLink ? (
            <Button variant="outline" asChild className="w-full mb-4">
              <a href={applyLink} target="_blank" rel="noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" /> Apply on {selectedJob.company}
              </a>
            </Button>
          ) : (
            <Button variant="outline" disabled className="w-full mb-4">
              <ExternalLink className="h-4 w-4 mr-2" /> No direct link available
            </Button>
          )
        )}
        <form onSubmit={submit} className="space-y-4">
          <Field label="Company Name"><Input required value={companyName} onChange={e => setCompanyName(e.target.value)} /></Field>
          <Field label="Job Title"><Input required value={targetRole} onChange={e => setTargetRole(e.target.value)} /></Field>
          <Field label="Job Description (full)"><Textarea required rows={8} value={jobDescription} onChange={e => setJobDescription(e.target.value)} placeholder="Full JD..." /></Field>
          <Field label="Resume (PDF or TXT)">
            <label className="flex items-center gap-2 border border-dashed border-border rounded-md px-3 py-3 cursor-pointer hover:bg-accent/40 transition-colors">
              <Upload className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm truncate">{fileName || "Choose file"}</span>
              <input type="file" accept="application/pdf,.pdf,.txt" className="hidden" onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
            </label>
          </Field>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Wand2 className="h-4 w-4 mr-2" /> Generate Coaching</>}
          </Button>
        </form>
      </Card>

      <div className="space-y-4">
        {loading && <Card className="p-6"><Spinner message="Analyzing resume vs JD..." /></Card>}
        {!loading && coach && (
          <>
            {applyLink && (
              <Card className="p-4 flex items-center justify-between gap-3 flex-wrap">
                <div className="text-sm text-muted-foreground">Apply to this role directly:</div>
                <Button asChild>
                  <a href={applyLink} target="_blank" rel="noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" /> Apply for this Job
                  </a>
                </Button>
              </Card>
            )}

            <CoachSection icon={Target} title="Match Analysis">
              <div className="flex items-start gap-4">
                {coach.matchScore != null && <MatchRing value={coach.matchScore} />}
                <p className="text-sm text-foreground/90 whitespace-pre-wrap flex-1">
                  {coach.matchSummary || "No summary."}
                </p>
              </div>
            </CoachSection>

            <CoachSection icon={Lightbulb} title="Skills to Add">
              {coach.skillsToAdd.length === 0 && <Empty>No missing skills.</Empty>}
              <div className="space-y-2">
                {coach.skillsToAdd.map((s, i) => (
                  <CopyRow key={i} copy={`${s.skill}${s.context ? ` — ${s.context}` : ""}`}>
                    <div className="text-sm"><span className="font-semibold text-primary">{s.skill}</span>{s.context && <span className="text-foreground/80"> — {s.context}</span>}</div>
                  </CopyRow>
                ))}
              </div>
            </CoachSection>

            <CoachSection icon={ListChecks} title="Bullet Points to Improve">
              {coach.bulletsToImprove.length === 0 && <Empty>No suggestions.</Empty>}
              <div className="space-y-3">
                {coach.bulletsToImprove.map((b, i) => (
                  <div key={i} className="rounded-lg border border-white/10 bg-white/5 p-3 space-y-2">
                    {b.original && (
                      <div className="text-xs text-muted-foreground line-through">{b.original}</div>
                    )}
                    <CopyRow copy={b.suggested}>
                      <div className="text-sm text-foreground/90">{b.suggested}</div>
                    </CopyRow>
                  </div>
                ))}
              </div>
            </CoachSection>

            <CoachSection icon={Tags} title="Keywords to Inject">
              {coach.keywordsToInject.length === 0 && <Empty>No keywords.</Empty>}
              <div className="space-y-2">
                {coach.keywordsToInject.map((k, i) => (
                  <CopyRow key={i} copy={k.sentence || k.keyword}>
                    <div className="text-sm">
                      <span className="font-semibold text-primary">{k.keyword}</span>
                      {k.sentence && <div className="text-foreground/80 mt-0.5">{k.sentence}</div>}
                    </div>
                  </CopyRow>
                ))}
              </div>
            </CoachSection>

            <CoachSection icon={LayoutList} title="Section Recommendations">
              {coach.sectionRecommendations.length === 0 && <Empty>No recommendations.</Empty>}
              <ul className="space-y-2">
                {coach.sectionRecommendations.map((r, i) => (
                  <CopyRow key={i} copy={r}>
                    <div className="text-sm flex gap-2"><span className="text-primary">•</span><span>{r}</span></div>
                  </CopyRow>
                ))}
              </ul>
            </CoachSection>

            <CoachSection icon={ClipboardCopy} title="Ready to Copy Snippets">
              {coach.snippets.length === 0 && <Empty>No snippets.</Empty>}
              <div className="space-y-2">
                {coach.snippets.map((s, i) => (
                  <CopyRow key={i} copy={s}>
                    <pre className="text-sm whitespace-pre-wrap font-mono text-foreground/90">{s}</pre>
                  </CopyRow>
                ))}
              </div>
            </CoachSection>

            <div className="flex justify-end">
              <Button onClick={() => goTo("prep")}>Proceed to Interview Prep <ArrowRight className="h-4 w-4 ml-2" /></Button>
            </div>
          </>
        )}
        {!loading && !coach && (
          <Card className="p-10 text-center text-muted-foreground border-dashed">
            <FileText className="h-10 w-10 mx-auto mb-3 opacity-50" />
            Your AI Resume Coach output will appear here
          </Card>
        )}
      </div>
    </div>
  );
}

function CoachSection({ icon: Icon, title, children }: { icon: any; title: string; children: React.ReactNode }) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="h-4 w-4 text-primary" />
        <h3 className="font-semibold text-sm">{title}</h3>
      </div>
      {children}
    </Card>
  );
}
function CopyRow({ copy, children }: { copy: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start gap-2 rounded-md hover:bg-white/5 px-2 py-1.5 -mx-2 group">
      <div className="flex-1 min-w-0">{children}</div>
      <button
        type="button"
        onClick={() => copyText(copy)}
        className="shrink-0 opacity-60 hover:opacity-100 text-muted-foreground hover:text-foreground transition-opacity p-1 rounded"
        title="Copy"
      >
        <Copy className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
function Empty({ children }: { children: React.ReactNode }) {
  return <p className="text-xs text-muted-foreground">{children}</p>;
}

/* -------- SCREEN 3: Interview Prep -------- */
const FOCUS_AREAS = ["Machine Learning", "Python", "System Design", "SQL", "Statistics"];

function PrepPlan() {
  const { selectedJob, prep, setPrep, goTo } = useApp();
  const [jobTitle, setJobTitle] = useState(selectedJob?.title || "");
  const [companyName, setCompanyName] = useState(selectedJob?.company || "");
  const [interviewDate, setInterviewDate] = useState(prep.interviewDate);
  const [startDate, setStartDate] = useState(prep.startDate);
  const [hoursPerDay, setHoursPerDay] = useState(prep.hoursPerDay);
  const [focus, setFocus] = useState<string[]>(prep.focusAreas);
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<string>(prep.prepPlan);

  useEffect(() => {
    if (selectedJob) {
      setJobTitle(selectedJob.title);
      setCompanyName(selectedJob.company);
    }
  }, [selectedJob]);

  const toggle = (a: string) => setFocus(f => f.includes(a) ? f.filter(x => x !== a) : [...f, a]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setPlan("");
    try {
      const data = await postJSON("/prep-plan", {
        jobTitle, companyName, interviewDate, startDate,
        hoursPerDay: Number(hoursPerDay), focusAreas: focus,
      });
      const planText = data?.prepPlan || data?.plan || (typeof data === "string" ? data : JSON.stringify(data, null, 2));
      setPlan(planText);
      setPrep({ interviewDate, startDate, hoursPerDay, focusAreas: focus, prepPlan: planText });
      toast.success("Prep plan generated");
    } catch (err: any) {
      toast.error(err.message || "Prep plan failed");
    } finally { setLoading(false); }
  };

  return (
    <div className="grid gap-6 md:grid-cols-[400px_1fr]">
      <Card className="p-6">
        <h2 className="text-xl font-bold mb-1 tracking-tight">Interview prep plan</h2>
        <p className="text-sm text-muted-foreground mb-5">A day-by-day study plan</p>
        {selectedJob && (
          <div className="mb-4 px-3 py-2 rounded-lg bg-primary/10 border border-primary/20 text-xs text-foreground/90">
            Pre-filled from <strong>{selectedJob.title}</strong> @ {selectedJob.company}
          </div>
        )}
        <form onSubmit={submit} className="space-y-4">
          <Field label="Company Name"><Input required value={companyName} onChange={e => setCompanyName(e.target.value)} /></Field>
          <Field label="Job Title"><Input required value={jobTitle} onChange={e => setJobTitle(e.target.value)} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Start Date"><Input type="date" required value={startDate} onChange={e => setStartDate(e.target.value)} /></Field>
            <Field label="Interview Date"><Input type="date" required value={interviewDate} onChange={e => setInterviewDate(e.target.value)} /></Field>
          </div>
          <Field label="Hours Per Day"><Input type="number" min={1} max={12} required value={hoursPerDay} onChange={e => setHoursPerDay(e.target.value)} /></Field>
          <div>
            <Label className="text-sm">Focus Areas</Label>
            <div className="mt-2 space-y-2">
              {FOCUS_AREAS.map(a => (
                <label key={a} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox checked={focus.includes(a)} onCheckedChange={() => toggle(a)} />
                  {a}
                </label>
              ))}
            </div>
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Sparkles className="h-4 w-4 mr-2" /> Generate Prep Plan</>}
          </Button>
        </form>
      </Card>

      <div className="space-y-4">
        {loading && <Card className="p-6"><Spinner message="Generating your prep plan..." /></Card>}
        {!loading && plan && (
          <>
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Your Prep Plan</h3>
              <Markdown content={plan} />
            </Card>
            <div className="flex justify-end">
              <Button onClick={() => goTo("schedule")}>Proceed to Save and Schedule <ArrowRight className="h-4 w-4 ml-2" /></Button>
            </div>
          </>
        )}
        {!loading && !plan && (
          <Card className="p-10 text-center text-muted-foreground border-dashed">
            <Sparkles className="h-10 w-10 mx-auto mb-3 opacity-50" />
            Your day-by-day plan will appear here
          </Card>
        )}
      </div>
    </div>
  );
}

function Markdown({ content }: { content: string }) {
  // Normalize literal "\n" escape sequences that may come from JSON-encoded strings
  const normalized = content.replace(/\\n/g, "\n").replace(/\\t/g, "    ");
  return (
    <div className="text-sm leading-relaxed text-foreground/90 space-y-3 [&_a]:text-primary [&_a]:underline [&_code]:bg-secondary [&_code]:px-1 [&_code]:py-0.5 [&_code]:rounded [&_code]:text-xs">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: (({ node, ...p }: any) => <h1 className="text-2xl font-bold mt-6 mb-2 tracking-tight" {...p} />) as any,
          h2: (({ node, ...p }: any) => <h2 className="text-xl font-bold mt-6 mb-2 text-primary" {...p} />) as any,
          h3: (({ node, ...p }: any) => <h3 className="text-base font-semibold mt-4 mb-1.5" {...p} />) as any,
          h4: (({ node, ...p }: any) => <h4 className="text-sm font-semibold mt-3 mb-1 uppercase tracking-wider text-muted-foreground" {...p} />) as any,
          p:  (({ node, ...p }: any) => <p className="leading-relaxed" {...p} />) as any,
          ul: (({ node, ...p }: any) => <ul className="space-y-1.5 pl-1" {...p} />) as any,
          ol: (({ node, className, ...p }: any) => <ol className={`list-decimal pl-6 space-y-1.5 ${className || ""}`} {...p} />) as any,
          li: (({ node, children, className, checked, ...p }: any) => {
            if (typeof checked === "boolean") {
              return (
                <li className="flex items-start gap-2 list-none" {...p}>
                  <span className={`mt-1 h-4 w-4 shrink-0 rounded border ${checked ? "bg-primary border-primary" : "border-white/30"} flex items-center justify-center`}>
                    {checked && <CheckCircle2 className="h-3 w-3 text-primary-foreground" />}
                  </span>
                  <span className={checked ? "line-through text-muted-foreground" : ""}>{children}</span>
                </li>
              );
            }
            return (
              <li className="flex gap-2" {...p}>
                <span className="text-primary mt-0.5">•</span>
                <span className="flex-1">{children}</span>
              </li>
            );
          }) as any,
          strong: (({ node, ...p }: any) => <strong className="font-semibold text-foreground" {...p} />) as any,
          em: (({ node, ...p }: any) => <em className="italic" {...p} />) as any,
          blockquote: (({ node, ...p }: any) => <blockquote className="border-l-2 border-primary/50 pl-3 italic text-muted-foreground" {...p} />) as any,
          hr: (() => <hr className="border-white/10 my-4" />) as any,
          a: (({ node, ...p }: any) => <a target="_blank" rel="noreferrer" {...p} />) as any,
          table: (({ node, ...p }: any) => <div className="overflow-auto"><table className="w-full text-sm border border-white/10 rounded" {...p} /></div>) as any,
          th: (({ node, ...p }: any) => <th className="text-left px-2 py-1 bg-white/5 border-b border-white/10" {...p} />) as any,
          td: (({ node, ...p }: any) => <td className="px-2 py-1 border-b border-white/5" {...p} />) as any,
        }}
      >
        {normalized}
      </ReactMarkdown>
    </div>
  );
}

/* -------- SCREEN 4: Save & Schedule -------- */
function SaveSchedule() {
  const { selectedJob, prep, coach } = useApp();
  const [savingDocs, setSavingDocs] = useState(false);
  const [scheduling, setScheduling] = useState(false);
  const [docsResult, setDocsResult] = useState<{ url?: string } | null>(null);
  const [calResult, setCalResult] = useState<boolean>(false);

  const companyName = selectedJob?.company || "";
  const jobTitle = selectedJob?.title || "";

  if (!companyName || !jobTitle || !prep.prepPlan) {
    return (
      <Card className="p-10 text-center text-muted-foreground border-dashed max-w-xl mx-auto">
        <Calendar className="h-10 w-10 mx-auto mb-3 opacity-50" />
        Complete the previous steps first — select a job, run the Resume Coach, and generate a prep plan.
      </Card>
    );
  }

  const saveDocs = async () => {
    setSavingDocs(true);
    try {
      const data = await postJSON("/save-docs", {
        companyName, jobTitle,
        prepPlan: prep.prepPlan.replace(/\\n/g, "\n").replace(/\\t/g, "    "),
        coach,
        jobDescription: selectedJob?.description || "",
        applyLink: selectedJob?.applyLink || "",
      });
      const url = data?.url || data?.docUrl;
      setDocsResult({ url });
      toast.success("Saved to Google Docs");
    } catch (err: any) {
      toast.error(err.message || "Save failed");
    } finally { setSavingDocs(false); }
  };

  const schedule = async () => {
    setScheduling(true);
    try {
      await postJSON("/schedule-calendar", {
        companyName, jobTitle,
        startDate: prep.startDate, interviewDate: prep.interviewDate,
        hoursPerDay: Number(prep.hoursPerDay),
        prepPlan: prep.prepPlan,
      });
      setCalResult(true);
      toast.success("Scheduled in your calendar");
    } catch (err: any) {
      toast.error(err.message || "Scheduling failed");
    } finally { setScheduling(false); }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card className="p-6">
        <h2 className="text-lg font-semibold">{jobTitle} @ {companyName}</h2>
        <p className="text-sm text-muted-foreground mt-1">
          {prep.startDate} → {prep.interviewDate} · {prep.hoursPerDay} hrs/day
        </p>
        {selectedJob?.applyLink && (
          <Button variant="outline" asChild className="mt-3">
            <a href={selectedJob.applyLink} target="_blank" rel="noreferrer">
              <ExternalLink className="h-4 w-4 mr-2" /> Apply for this Job
            </a>
          </Button>
        )}
      </Card>

      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-6">
          <Save className="h-6 w-6 text-primary mb-3" />
          <h3 className="font-semibold mb-1">Save to Google Docs</h3>
          <p className="text-sm text-muted-foreground mb-4">Export coaching and prep plan as a doc.</p>
          <Button onClick={saveDocs} disabled={savingDocs} className="w-full">
            {savingDocs ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Saving...</> : "Save to Google Docs"}
          </Button>
          {docsResult && (
            <div className="mt-3 text-xs text-primary flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5" /> Saved
              {docsResult.url && <a href={docsResult.url} target="_blank" rel="noreferrer" className="underline ml-1">Open</a>}
            </div>
          )}
        </Card>

        <Card className="p-6">
          <Calendar className="h-6 w-6 text-primary mb-3" />
          <h3 className="font-semibold mb-1">Schedule in Calendar</h3>
          <p className="text-sm text-muted-foreground mb-4">Block out your study sessions.</p>
          <Button onClick={schedule} disabled={scheduling} className="w-full">
            {scheduling ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Scheduling...</> : "Schedule in Calendar"}
          </Button>
          {calResult && (
            <div className="mt-3 text-xs text-primary flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5" /> Added to calendar
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

/* -------- helpers -------- */
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm">{label}</Label>
      {children}
    </div>
  );
}
